#!/bin/bash
docker push YourRes:Tag
