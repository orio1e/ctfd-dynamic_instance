<?php


phpinfo();


?>

