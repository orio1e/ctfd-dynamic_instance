#!/bin/bash
docker build -t YourResp:Tag .